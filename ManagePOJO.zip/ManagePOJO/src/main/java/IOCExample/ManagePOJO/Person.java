package IOCExample.ManagePOJO;

import java.util.List;

public class Person {
	
	String firstName;
	String lastName;
	List<Address> adresses;
	long adharNo;
	public Person() {
		super();
	}
	public Person(String firstName, String lastName, List<Address> adresses, long adharNo) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.adresses = adresses;
		this.adharNo = adharNo;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public List<Address> getAdresses() {
		return adresses;
	}
	public void setAdresses(List<Address> adresses) {
		this.adresses = adresses;
	}
	public long getAdharNo() {
		return adharNo;
	}
	public void setAdharNo(long adharNo) {
		this.adharNo = adharNo;
	}
	@Override
	public String toString() {
		return "Person [firstName=" + firstName + ", lastName=" + lastName + ", adresses=" + adresses + ", adharNo="
				+ adharNo + "]";
	}

	
}
