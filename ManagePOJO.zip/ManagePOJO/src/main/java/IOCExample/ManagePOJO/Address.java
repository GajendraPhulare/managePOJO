package IOCExample.ManagePOJO;

public class Address {
	
	String streetNo;
	String citName;
	String stateName;
	String  countryName;
	public Address() {
		super();
	}
	public Address(String streetNo, String citName, String stateName, String countryName) {
		super();
		this.streetNo = streetNo;
		this.citName = citName;
		this.stateName = stateName;
		this.countryName = countryName;
	}
	public String getStreetNo() {
		return streetNo;
	}
	public void setStreetNo(String streetNo) {
		this.streetNo = streetNo;
	}
	public String getCitName() {
		return citName;
	}
	public void setCitName(String citName) {
		this.citName = citName;
	}
	public String getStateName() {
		return stateName;
	}
	public void setStateName(String stateName) {
		this.stateName = stateName;
	}
	public String getCountryName() {
		return countryName;
	}
	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}
	@Override
	public String toString() {
		return "Address [streetNo=" + streetNo + ", citName=" + citName + ", stateName=" + stateName + ", countryName="
				+ countryName + "]";
	}
	
	

}
