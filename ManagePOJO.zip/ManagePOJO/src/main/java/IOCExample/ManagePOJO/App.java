package IOCExample.ManagePOJO;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;


public class App 
{
    public static void main( String[] args )
    {
        ApplicationContext applicationContext=new FileSystemXmlApplicationContext("C:\\Users\\phulagaj\\Spring\\ManagePOJO\\src\\main\\java\\IOCExample\\ManagePOJO\\beans.xml");
       Person person=applicationContext.getBean(Person.class);
       System.out.println(person.toString());
    }
}
